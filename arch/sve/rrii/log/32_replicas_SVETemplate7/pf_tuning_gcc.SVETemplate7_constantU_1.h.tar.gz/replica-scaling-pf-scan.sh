#!/bin/bash

for r in 1 ; do 
  for i in `seq 1 4` ; do 
    for j in `seq 0 4` ; do 
      for k in `seq 0 7` ; do 
	OMP_NUM_THREADS=12 numactl --cpunodebind=0 --membind=0 ./bench.rrii.sve.intrinsics.gcc $r 5000 $i -$j -$k 2> /dev/null | grep XX1 ; 
      done ; 
    done ;
  done | tee log.$r.replica.gcc ; 
done

for r in 4 ; do 
  for i in `seq 1 4` ; do 
    for j in `seq 0 4` ; do 
      for k in `seq 0 7` ; do 
	OMP_NUM_THREADS=12 numactl --cpunodebind=0 --membind=0 ./bench.rrii.sve.intrinsics.gcc $r 2000 $i -$j -$k 2> /dev/null | grep XX1 ; 
      done ; 
    done ;
  done | tee log.$r.replica.gcc ; 
done


for r in 8 ; do 
  for i in `seq 1 4` ; do 
    for j in `seq 0 4` ; do 
      for k in `seq 0 7` ; do 
	OMP_NUM_THREADS=12 numactl --cpunodebind=0 --membind=0 ./bench.rrii.sve.intrinsics.gcc $r 1000 $i -$j -$k 2> /dev/null | grep XX1 ; 
      done ; 
    done ;
  done | tee log.$r.replica.gcc ; 
done

for r in 16 32 ; do 
  for i in `seq 1 4` ; do 
    for j in `seq 0 4` ; do 
      for k in `seq 0 7` ; do 
	OMP_NUM_THREADS=12 numactl --cpunodebind=0 --membind=0 ./bench.rrii.sve.intrinsics.gcc $r 500 $i -$j -$k 2> /dev/null | grep XX1 ; 
      done ; 
    done ;
  done | tee log.$r.replica.gcc ; 
done



